<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

_deprecated_file( esc_html( basename( __FILE__ ) ), '3.0', null, 'FrmFieldsHelper::show_single_option' );
FrmFieldsHelper::show_single_option( $field );
