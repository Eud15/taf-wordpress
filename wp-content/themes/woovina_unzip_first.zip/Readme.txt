----------------------------------------------------------------------
--   WooVina - Free WooCommerce WordPress Theme						--
--   Home Page: https://woovina.com									--
--   Documentation: https://woovina.com/docs						--
--	 Tickets Support: https://woovina.com/my-account/my-tickets		--
--	 Community Support: https://www.facebook.com/WooVinaTheme/		--
--	 Email: admin@woovina.com	- Skype: mr.hiennc					--
----------------------------------------------------------------------


Thanks for download WooVina theme! 
Please follow this to getting started:

STEP 1: Install & Activate WooVina Theme: 
	- Login to backend of your website, go to Appearance >> Themes >> Add New >> Upload Theme.
	- Browse the file: woovina.zip and click Install Now.
	- Click on the link Activate in next screen to activate WooVina theme.

STEP 2: Install Requires & Recommended Plugins: 
	- Click on the link "Begin installing plugins" in next screen: https://nimb.ws/Wj32Hh
	- Select all plugins to install and click Apply button: https://nimb.ws/H04dEZ


1. How to Install WooVina Theme? 		https://woovina.com/docs/getting-started/how-to-install-woovina-theme
2. How to Import a Free Demo? 			https://woovina.com/docs/getting-started/how-to-import-a-free-demo
3. Theme Installation Errors? 			https://woovina.com/docs/getting-started/theme-installation-errors
4. How to activate Priority License? 	https://woovina.com/docs/getting-started/how-to-activate-the-license-of-the-priority-support-child-themes

Have any questions or need any help, please submit a ticket here: https://woovina.com/my-account/my-tickets